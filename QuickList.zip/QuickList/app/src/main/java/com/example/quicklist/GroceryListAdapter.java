package com.example.quicklist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import java.util.Locale;

public class GroceryListAdapter extends ArrayAdapter<GroceryList> {

    private final LayoutInflater mInflater;
    private final int mResource;

    public GroceryListAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<GroceryList> objects) {
        super(context, resource, objects);
        mInflater = LayoutInflater.from(context);
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view;
        if (convertView == null) {
            view = mInflater.inflate(mResource, parent, false);
        } else {
            view = convertView;
        }

        GroceryList groceryList = getItem(position);

        TextView listNameTextView = view.findViewById(R.id.list_name_textview);
        TextView listItemsCountTextView = view.findViewById(R.id.list_items_count_textview);

        if (groceryList != null) {
            listNameTextView.setText(groceryList.getListName());
            listItemsCountTextView.setText(String.format(Locale.getDefault(), "%d items", groceryList.getItems().size()));
        }

        return view;
    }
}
