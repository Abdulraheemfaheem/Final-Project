package com.example.quicklist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class ViewListActivity extends AppCompatActivity {

    private ListView listViewGroceryItems;
    private ArrayList<String> groceryItems;
    private ArrayAdapter<String> groceryItemsAdapter;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list);

        listViewGroceryItems = findViewById(R.id.listViewGroceryItems);

        GroceryList groceryList = (GroceryList) getIntent().getSerializableExtra("grocery_list");
        username = getIntent().getStringExtra("username"); // Get the username from the Intent
        if (groceryList != null) {
            groceryItems = groceryList.getItems();
        } else {
            groceryItems = new ArrayList<>();
        }

        groceryItemsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, groceryItems);
        listViewGroceryItems.setAdapter(groceryItemsAdapter);

        listViewGroceryItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ViewListActivity.this);
                builder.setTitle("Edit Item");

                final EditText input = new EditText(ViewListActivity.this);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                input.setText(groceryItems.get(position));
                builder.setView(input);

                builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String updatedItem = input.getText().toString();
                        groceryItems.set(position, updatedItem);
                        groceryItemsAdapter.notifyDataSetChanged();


                        GroceryList updatedGroceryList = new GroceryList(groceryList.getKey(), groceryList.getListName(), groceryItems, username);

                        DatabaseReference groceryListRef = FirebaseDatabase.getInstance().getReference().child("grocery_lists").child(username).child(groceryList.getKey());
                        groceryListRef.setValue(updatedGroceryList);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
                return true;
            }
        });
    }
}
