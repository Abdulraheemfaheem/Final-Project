package com.example.quicklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.app.AlertDialog;
import android.content.DialogInterface;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class SavedListsActivity extends AppCompatActivity {

    private ListView listViewSavedLists;
    private ArrayList<GroceryList> groceryLists;
    private GroceryListAdapter groceryListAdapter;

    private DatabaseReference databaseRef;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_lists);

        listViewSavedLists = findViewById(R.id.listViewSavedLists);

        groceryLists = new ArrayList<>();
        groceryListAdapter = new GroceryListAdapter(this, R.layout.item_grocery_list, groceryLists);
        listViewSavedLists.setAdapter(groceryListAdapter);

        username = getIntent().getStringExtra("username"); // get the username from the intent

        if (username == null) {
            finish();
            return;
        }

        databaseRef = FirebaseDatabase.getInstance().getReference().child("grocery_lists").child(username);
        databaseRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {
                GroceryList groceryList = dataSnapshot.getValue(GroceryList.class);
                if (groceryList != null) {
                    groceryLists.add(groceryList);
                    groceryListAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {
                // Handle any changes to the grocery lists if needed
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                // Handle any removal of grocery lists if needed
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {
                // Handle any movement of grocery lists if needed
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle any errors during the process
            }
        });

        listViewSavedLists.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(SavedListsActivity.this, ViewListActivity.class);
                intent.putExtra("grocery_list", groceryLists.get(position));
                intent.putExtra("username", username); // pass the username to ViewListActivity
                startActivity(intent);
            }
        });

        listViewSavedLists.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SavedListsActivity.this);
                builder.setTitle("Delete List");

                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        GroceryList groceryListToDelete = groceryLists.get(position);
                        // Remove the grocery list locally
                        groceryLists.remove(position);
                        groceryListAdapter.notifyDataSetChanged();

                        // Remove the grocery list from Firebase
                        DatabaseReference groceryListRef = FirebaseDatabase.getInstance().getReference().child("grocery_lists").child(username).child(groceryListToDelete.getKey());
                        groceryListRef.removeValue();
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
                return true;
            }
        });
    }
}
