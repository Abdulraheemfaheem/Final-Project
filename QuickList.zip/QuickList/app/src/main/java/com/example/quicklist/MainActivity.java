package com.example.quicklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> items;
    private ArrayAdapter<String> itemsAdapter;
    private ListView listViewItems;
    private Button buttonAdd;
    private Button buttonSave;
    private Button buttonHome;
    private EditText editTextItem;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = getIntent().getStringExtra("username"); // Get the username from the Intent

        // Check if username is null
        if (username == null) {
            // Show an error message
            Toast.makeText(MainActivity.this, "Username is required", Toast.LENGTH_SHORT).show();

            // Finish this activity and go back to the previous one
            finish();
            return;
        }

        listViewItems = findViewById(R.id.listViewItems);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSave = findViewById(R.id.buttonSave);
        buttonHome = findViewById(R.id.buttonHome);
        editTextItem = findViewById(R.id.editTextItem);

        items = new ArrayList<>();
        itemsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listViewItems.setAdapter(itemsAdapter);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newItem = editTextItem.getText().toString();
                if (!newItem.isEmpty()) {
                    itemsAdapter.add(newItem);
                    editTextItem.setText("");
                }
            }
        });

        listViewItems.setOnItemLongClickListener((parent, view, position, id) -> {
            items.remove(position);
            itemsAdapter.notifyDataSetChanged();
            return true;
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!items.isEmpty()) {
                    DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference().child("grocery_lists").child(username);
                    String listId = databaseRef.push().getKey();

                    GroceryList groceryList = new GroceryList(listId, "ListName", items, username); // Include username
                    saveGroceryList(databaseRef, groceryList);

                    items.clear();
                    itemsAdapter.notifyDataSetChanged();

                    Intent intent = new Intent(MainActivity.this, SavedListsActivity.class);
                    intent.putExtra("username", username); // pass the username to SavedListsActivity
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "No items to save", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }

    private void saveGroceryList(DatabaseReference databaseRef, GroceryList groceryList) {
        databaseRef.child(groceryList.getKey()).setValue(groceryList)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "Grocery list saved", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Failed to save grocery list", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
