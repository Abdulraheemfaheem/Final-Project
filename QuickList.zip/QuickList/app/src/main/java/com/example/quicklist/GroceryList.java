package com.example.quicklist;

import java.io.Serializable;
import java.util.ArrayList;

public class GroceryList implements Serializable {
    private String key;
    private String listName;
    private ArrayList<String> items;
    private String username;

    public GroceryList() {
        items = new ArrayList<>();
    }

    public GroceryList(String key, String listName, ArrayList<String> items, String username) {
        this.key = key;
        this.listName = listName;
        this.items = items != null ? items : new ArrayList<>();
        this.username = username;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public ArrayList<String> getItems() {
        return items;
    }

    public void setItems(ArrayList<String> items) {
        this.items = items != null ? items : new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
